import time
from datetime import datetime

def send_to_ml_service(s3_url):
    """ЗАГЛУШКА: имитируем отправку в ML сервис"""
    
    # Имитируем обработку
    time.sleep(2)
    
    # Имитируем успешный ответ от ML сервиса
    return {
        "status": "accepted", 
        "message": "Видео принято в обработку",
        "job_id": f"job_{datetime.now().strftime('%Y%m%d_%H%M%S')}",
        "estimated_time": "5-10 минут"
    }