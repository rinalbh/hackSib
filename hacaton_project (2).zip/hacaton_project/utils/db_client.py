from clickhouse_connect import get_client
import random
from datetime import datetime, timedelta

def get_client_connection():
    """Создает подключение к ClickHouse"""
    try:
        client = get_client(
            host='iqydclkqtr.us-east1.gcp.clickhouse.cloud',  # замени на твой хост
            port=8443,
            username='default',
            password=''  # если есть пароль
        )
        return client
    except Exception as e:
        print(f"Ошибка подключения к ClickHouse: {e}")
        return None

def save_upload_metadata(filename, s3_url, upload_time):
    """Сохраняем метаданные о загрузке в ClickHouse"""
    
    client = get_client_connection()
    if not client:
        return False
    
    try:
        # Создаем таблицу если нет
        client.command('''
            CREATE TABLE IF NOT EXISTS video_uploads (
                id UUID DEFAULT generateUUIDv4(),
                filename String,
                s3_url String,
                upload_time DateTime DEFAULT now(),
                status String DEFAULT 'uploaded'
            ) ENGINE = MergeTree()
            ORDER BY upload_time
        ''')
        
        # Сохраняем данные
        client.insert('video_uploads', [{
            'filename': filename,
            's3_url': s3_url,
            'upload_time': upload_time
        }])
        
        # Также создаем таблицу для метрик анализа если нет
        client.command('''
            CREATE TABLE IF NOT EXISTS video_analysis (
                id UUID DEFAULT generateUUIDv4(),
                s3_url String,
                analysis_time DateTime DEFAULT now(),
                people_count Int32,
                efficiency Float32,
                violations Int32,
                activities String
            ) ENGINE = MergeTree()
            ORDER BY analysis_time
        ''')
        
        # Добавляем тестовые метрики для этого видео
        client.insert('video_analysis', [{
            's3_url': s3_url,
            'people_count': random.randint(1, 10),
            'efficiency': round(random.uniform(0.5, 0.95), 2),
            'violations': random.randint(0, 5),
            'activities': 'working, walking, lifting'
        }])
        
        return True
        
    except Exception as e:
        print(f"Ошибка сохранения в БД: {e}")
        return False

def get_videos_from_db():
    """Получаем список всех видео из базы"""
    
    client = get_client_connection()
    if not client:
        return []
    
    try:
        result = client.query('''
            SELECT filename, s3_url, upload_time 
            FROM video_uploads 
            ORDER BY upload_time DESC
        ''')
        return result.result_rows
    except Exception as e:
        print(f"Ошибка получения видео: {e}")
        return []

def get_video_metrics(s3_url):
    """Получаем метрики для конкретного видео"""
    
    client = get_client_connection()
    if not client:
        return None
    
    try:
        result = client.query('''
            SELECT people_count, efficiency, violations, activities
            FROM video_analysis 
            WHERE s3_url = %(url)s
            ORDER BY analysis_time DESC 
            LIMIT 1
        ''', {'url': s3_url})
        
        return result.result_rows[0] if result.result_rows else None
    except Exception as e:
        print(f"Ошибка получения метрик: {e}")
        return None