import streamlit as st
import tempfile
import os
from datetime import datetime
from utils.s3_client import upload_to_s3
from utils.ml_client import send_to_ml_service
from utils.db_client import save_upload_metadata

st.set_page_config(page_title="Загрузка видео", layout="centered")
st.title("📤 Загрузка видео")

uploaded_file = st.file_uploader("Выберите видео файл", type=['mp4', 'avi', 'mov'])

if uploaded_file:
    # Показываем превью
    st.video(uploaded_file)
    
    if st.button("Загрузить видео", type="primary"):
        with st.spinner("Загружаем видео..."):
            # 1. "Загружаем в S3" (на самом деле в локальную папку)
            s3_url = upload_to_s3(uploaded_file)
            st.success(f"✅ Видео сохранено: {s3_url}")
            
            # 2. "Отправляем в ML сервис"
            with st.spinner("Отправляем в ML сервис..."):
                ml_response = send_to_ml_service(s3_url)
            
            if ml_response.get("status") == "accepted":
                st.success("🎯 Видео принято в обработку")
                
                # 3. Сохраняем метаданные в ClickHouse
                save_upload_metadata(
                    uploaded_file.name, 
                    s3_url, 
                    datetime.now()
                )
                
                st.info("📊 Тестовые метрики добавлены в ClickHouse")
                
                # Показываем пример метрик
                with st.expander("Пример добавленных метрик"):
                    st.json({
                        "people_count": "3-10 (случайно)",
                        "efficiency": "50-95% (случайно)", 
                        "violations": "0-5 (случайно)",
                        "activities": "working, walking, lifting"
                    })
            else:
                st.error("❌ Ошибка отправки в ML сервис")