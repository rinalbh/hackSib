import streamlit as st
import os

# Настройки страницы
st.set_page_config(
    page_title="Video Analytics Platform",
    page_icon="🎥",
    layout="wide",
    initial_sidebar_state="expanded"
)

# Создаем папку для локального S3
os.makedirs("local_s3_storage/videos", exist_ok=True)

# Главная страница с описанием
st.title("🎥 Платформа анализа видео")
st.markdown("""
Добро пожаловать в систему анализа производственных видео!
            
**Возможности:**
- 📤 Загрузка видео для анализа
- 📺 Просмотр обработанных видео с метриками
- 📊 Анализ эффективности и безопасности

Используйте боковое меню для навигации.
""")

# Информация о системе
with st.expander("ℹ️ Информация о системе"):
    st.write("""
    **Текущий режим:** Демо-версия
    - S3: Локальная файловая система
    - ML сервис: Заглушка
    - База данных: ClickHouse
    """)