import streamlit as st
import os
from utils.db_client import init_database

# Настройки страницы
st.set_page_config(
    page_title="Video Analytics Platform",
    page_icon="🎥",
    layout="wide",
    initial_sidebar_state="expanded"
)

# Создаем папку для локального S3
os.makedirs("local_s3_storage/videos", exist_ok=True)

# Инициализация БД при запуске приложения
if 'app_initialized' not in st.session_state:
    if init_database():
        st.session_state.app_initialized = True

# Главная страница с описанием
st.title("🎥 Платформа анализа видео")
st.markdown("""
Добро пожаловать в систему анализа производственных видео!

**Возможности:**
- 📤 Загрузка видео для анализа
- 📺 Просмотр обработанных видео с метриками
- 📊 Анализ эффективности и безопасности

Используйте боковое меню для навигации.
""")

# Информация о системе
with st.expander("ℹ️ Информация о системе"):
    st.write("""
    **Текущий режим:** Демо-версия
    - S3: Локальная файловая система
    - ML сервис: Заглушка
    - База данных: ClickHouse Cloud
    """)
    
    # Проверка подключения к ClickHouse
    if st.button("🔍 Проверить подключение к ClickHouse Cloud"):
        from utils.db_client import execute_query
        result = execute_query('SELECT 1 as test')
        if result['success']:
            st.success("✅ Подключение к ClickHouse Cloud успешно!")
            
            # Покажем информацию о таблицах
            tables_result = execute_query('SHOW TABLES')
            if tables_result['success']:
                st.write("**Существующие таблицы:**")
                st.code(tables_result['data'])
        else:
            st.error(f"❌ Ошибка подключения: {result['error']}")

# Очистка всей сессии
if st.button("🔄 Полный сброс приложения"):
    for key in list(st.session_state.keys()):
        del st.session_state[key]
    st.success("Сессия полностью сброшена!")
    st.rerun()