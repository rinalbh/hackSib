import streamlit as st
import tempfile
import os
from datetime import datetime
from utils.s3_client import upload_to_s3
from utils.ml_client import send_to_ml_service
from utils.db_client import save_upload_metadata, init_database

st.set_page_config(page_title="Загрузка видео", layout="centered")
st.title("📤 Загрузка видео")

# Инициализация глобального состояния
if 'app_state' not in st.session_state:
    st.session_state.app_state = {
        'uploaded_files': [],
        'db_initialized': False,
        'current_video_path': None
    }

# Инициализируем БД один раз при загрузке
if not st.session_state.app_state['db_initialized']:
    if init_database():
        st.session_state.app_state['db_initialized'] = True

# Кнопка очистки кэша
col1, col2 = st.columns([3, 1])
with col2:
    if st.button("🧹 Очистить кэш", type="secondary"):
        st.cache_data.clear()
        st.session_state.app_state['uploaded_files'] = []
        if st.session_state.app_state['current_video_path'] and os.path.exists(st.session_state.app_state['current_video_path']):
            os.unlink(st.session_state.app_state['current_video_path'])
        st.session_state.app_state['current_video_path'] = None
        st.success("Кэш очищен!")
        st.rerun()

uploaded_file = st.file_uploader("Выберите видео файл", type=['mp4', 'avi', 'mov'])

if uploaded_file:
    # Показываем превью
    st.video(uploaded_file)
    
    # Проверяем, не загружали ли уже этот файл в текущей сессии
    file_already_uploaded = any(
        f['name'] == uploaded_file.name and 
        f['size'] == uploaded_file.size 
        for f in st.session_state.app_state['uploaded_files']
    )
    
    if not file_already_uploaded:
        if st.button("Загрузить видео", type="primary"):
            with st.spinner("Загружаем видео..."):
                # 1. "Загружаем в S3" (на самом деле в локальную папку)
                s3_url = upload_to_s3(uploaded_file)
                st.success(f"✅ Видео сохранено: {s3_url}")
                
                # 2. "Отправляем в ML сервис"
                with st.spinner("Отправляем в ML сервис..."):
                    ml_response = send_to_ml_service(s3_url)
                
                if ml_response.get("status") == "accepted":
                    st.success("🎯 Видео принято в обработку")
                    
                    # 3. Сохраняем метаданные в ClickHouse
                    if save_upload_metadata(
                        uploaded_file.name, 
                        s3_url, 
                        datetime.now()
                    ):
                        st.balloons()
                        
                        # Сохраняем информацию о файле в глобальном состоянии
                        file_info = {
                            'name': uploaded_file.name,
                            'size': uploaded_file.size,
                            'type': uploaded_file.type,
                            's3_url': s3_url,
                            'timestamp': datetime.now(),
                            'processed': True
                        }
                        st.session_state.app_state['uploaded_files'].append(file_info)
                        
                        # Показываем пример метрик
                        with st.expander("📊 Просмотр добавленных метрик"):
                            st.json({
                                "people_count": "1-10 (случайно)",
                                "efficiency": "50-95% (случайно)", 
                                "violations": "0-5 (случайно)",
                                "activities": "working, walking, lifting"
                            })
                else:
                    st.error("❌ Ошибка отправки в ML сервис")
    else:
        st.info("ℹ️ Это видео уже было загружено в текущей сессии")

# Показываем историю загруженных файлов в этой сессии
if st.session_state.app_state['uploaded_files']:
    st.markdown("---")
    st.subheader("📋 Загруженные в этой сессии файлы:")
    
    for file_info in st.session_state.app_state['uploaded_files']:
        status = "✅ Обработан" if file_info.get('processed') else "⏳ Ожидает обработки"
        timestamp = file_info['timestamp'].strftime('%H:%M:%S') if isinstance(file_info['timestamp'], datetime) else str(file_info['timestamp'])
        st.write(f"- **{file_info['name']}** ({status}) - {timestamp}")