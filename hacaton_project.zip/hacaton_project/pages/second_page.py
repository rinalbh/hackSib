import streamlit as st
import os
from utils.db_client import get_videos_from_db, get_video_metrics
from utils.s3_client import download_from_s3
from datetime import datetime

st.set_page_config(page_title="Просмотр видео", layout="wide")
st.title("📺 Просмотр видео")

# Кнопка очистки кэша
if st.button("🧹 Очистить кэш страницы", type="secondary"):
    st.cache_data.clear()
    st.success("Кэш страницы очищен!")
    st.rerun()

# Получаем список видео из БД
videos = get_videos_from_db()

if videos:
    st.header("Доступные видео:")
    
    for filename, s3_url, upload_time in videos:
        col1, col2, col3 = st.columns([3, 1, 1])
        
        with col1:
            st.write(f"**{filename}**")
            
            # Исправляем преобразование даты
            if isinstance(upload_time, str):
                # Если дата пришла как строка из БД
                try:
                    # Пробуем разные форматы даты
                    if 'T' in upload_time:
                        # Формат: 2024-11-29T14:03:18
                        dt = datetime.fromisoformat(upload_time.replace('Z', ''))
                    else:
                        # Формат: 2024-11-29 14:03:18
                        dt = datetime.strptime(upload_time, '%Y-%m-%d %H:%M:%S')
                    display_time = dt.strftime('%Y-%m-%d %H:%M')
                except:
                    display_time = upload_time  # Оставляем как есть если не получилось
            elif isinstance(upload_time, datetime):
                # Если уже datetime объект
                display_time = upload_time.strftime('%Y-%m-%d %H:%M')
            else:
                display_time = str(upload_time)
                
            st.write(f"Загружено: {display_time}")
        
        with col2:
            if st.button("Смотреть", key=f"watch_{s3_url}"):
                st.session_state.selected_video = {
                    'filename': filename,
                    's3_url': s3_url
                }
                st.rerun()
        
        with col3:
            if st.button("Метрики", key=f"metrics_{s3_url}"):
                st.session_state.show_metrics_for = s3_url
                st.rerun()
        
        st.divider()

# Показ метрик для конкретного видео
if 'show_metrics_for' in st.session_state:
    s3_url = st.session_state.show_metrics_for
    metrics = get_video_metrics(s3_url)
    
    if metrics:
        st.subheader("📊 Метрики анализа")
        col1, col2, col3 = st.columns(3)
        
        people, efficiency, violations, activities = metrics
        col1.metric("Людей", people)
        col2.metric("Эффективность", f"{efficiency*100:.1f}%")
        col3.metric("Нарушения", violations)
        
        st.write(f"**Активности:** {activities}")
    
    if st.button("← Назад к списку"):
        del st.session_state.show_metrics_for
        st.rerun()

# Показ выбранного видео
if 'selected_video' in st.session_state:
    video_data = st.session_state.selected_video
    
    st.header(f"🎥 {video_data['filename']}")
    
    with st.spinner("Загружаем видео..."):
        # "Скачиваем" видео из нашего локального S3
        video_path = download_from_s3(video_data['s3_url'])
        
        if video_path:
            # Показываем видео
            st.video(video_path)
            
            # Сохраняем путь к временному файлу для очистки
            st.session_state.temp_video_path = video_path
            
            # Показываем метрики
            metrics = get_video_metrics(video_data['s3_url'])
            if metrics:
                st.subheader("📊 Метрики этого видео")
                people, efficiency, violations, activities = metrics
                
                col1, col2, col3, col4 = st.columns(4)
                col1.metric("Людей", people)
                col2.metric("Эффективность", f"{efficiency*100:.1f}%")
                col3.metric("Нарушения", violations)
                col4.metric("Активности", activities.split(',')[0] if activities else "N/A")
            
            # Кнопка для возврата к списку
            if st.button("← Назад к списку"):
                # Удаляем временный файл если существует
                if 'temp_video_path' in st.session_state:
                    if os.path.exists(st.session_state.temp_video_path):
                        os.unlink(st.session_state.temp_video_path)
                    del st.session_state.temp_video_path
                
                del st.session_state.selected_video
                st.rerun()

else:
    if not videos:
        st.info("📝 Пока нет загруженных видео. Перейдите на страницу загрузки!")